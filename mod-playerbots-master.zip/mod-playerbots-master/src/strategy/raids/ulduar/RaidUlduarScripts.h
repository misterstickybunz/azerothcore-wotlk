#ifndef _PLAYERBOT_RAIDULDUARSCRIPTS_H
#define _PLAYERBOT_RAIDULDUARSCRIPTS_H

#include "../../../../src/server/scripts/Northrend/Ulduar/Ulduar/ulduar.h"

#endif
